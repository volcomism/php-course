<?php

function redirect($target) {
				
				      echo "<script>
				      <!--  
				      	window.location= \"".$target."\"   
				      //-->
				      </script>";

}

?>